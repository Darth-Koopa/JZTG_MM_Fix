*** FONT FIX MOD ***
Place this folder in SD:\rhmm.
This will probably not work with the Fever Font mod. You have been warned.